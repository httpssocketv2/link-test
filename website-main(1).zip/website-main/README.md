**Website**: https://cliphd.ga

### FAQ
* **What do you use to host? Is it free?**

I use [netlify.com](https://netlify.com) to host and yes, it's free.
* **Where did you get your domain?**

I got my domain from [freenom.com](https://freenom.com) and it's completely free.
